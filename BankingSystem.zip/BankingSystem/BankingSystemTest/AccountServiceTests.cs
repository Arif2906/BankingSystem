﻿using BankingSystem.Controllers;
using BankingSystem.Interface;
using BankingSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BankingSystemTest
{
    public class AccountServiceTests
    {
        private IUserAccountService userAccountService= new UserAccountService();
        private IUserService userService = new UserService(new UserAccountService());
        [Fact]
        public void CreateAccount_ShouldReturnNewAccount()
        {
            var accountService = new AccountService(userAccountService, userService);
            var userId = 1;
            var account = accountService.CreateAccount(userId);
            Assert.NotNull(account);
            Assert.Equal(userId, account.UserId);
        }

        [Fact]
        public void Deposit_ShouldIncreaseAccountBalance()
        {
            var accountService = new AccountService(userAccountService, userService);
            var account = accountService.CreateAccount(1);
            var initialBalance = account.Balance;
            var newBalance = accountService.Deposit(account.Id, 100);
            Assert.Equal(initialBalance + 100, newBalance);
        }

        [Fact]
        public void DeleteAccount_ShouldRemoveAccount()
        {
            var accountService = new AccountService(userAccountService, userService);
            var account = accountService.CreateAccount(1);
            accountService.DeleteAccount(account.Id);

            Assert.Empty(accountService.GetAccounts()); 
        }

        [Fact]
        public void Account_Withdraw_ShouldDecreaseBalance()
        {
            var account = new Account { Id = 2, UserId = 1, Balance = 800 };
            var accountService = new AccountService(userAccountService, userService);
            var newBalance = accountService.Withdraw(account.Id, 300);
            Assert.Equal(500, newBalance);
        }
    }
}
