﻿using BankingSystem.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BankingSystemTest
{
    public class UserServiceTests
    {

        [Fact]
        public void CreateUser_ShouldReturnNewUser()
        {
            var userService = new UserService(new UserAccountService());
            var user = userService.CreateUser("John Doe");
            Assert.NotNull(user);
            Assert.Equal("John Doe", user.Name);
        }
    }
}
