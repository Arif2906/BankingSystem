using BankingSystem.Controllers;
using BankingSystem.Interface;
using BankingSystem.Model;
using NUnit.Framework;

namespace BankingSystemTest
{
    public class AccountServiceTests
    {
        private IUserAccountService _userAccountService;
        private IUserService _userService;

        [SetUp]
        public void Setup()
        {
            _userAccountService = new UserAccountService();
            _userService = new UserService(_userAccountService);
        }

        private AccountService CreateAccountService()
        {
            return new AccountService(_userAccountService, _userService);
        }

        [Test]
        public void CreateAccount_ShouldReturnNewAccount()
        {
            var accountService = CreateAccountService();
            var userId = 1;

            var account = accountService.CreateAccount(userId);

            Assert.NotNull(account);
            Assert.AreEqual(userId, account.UserId);
        }

        [Test]
        public void Deposit_ShouldIncreaseAccountBalance()
        {
            var accountService = CreateAccountService();
            var account = accountService.CreateAccount(1);
            var initialBalance = account.Balance;

            var newBalance = accountService.Deposit(account.Id, 100);

            Assert.AreEqual(initialBalance + 100, newBalance);
        }

        [Test]
        public void DeleteAccount_ShouldRemoveAccount()
        {
            var accountService = CreateAccountService();
            var account = accountService.CreateAccount(1);
            accountService.DeleteAccount(account.Id);

            Assert.IsEmpty(accountService.GetAccounts());
        }
    }
}
