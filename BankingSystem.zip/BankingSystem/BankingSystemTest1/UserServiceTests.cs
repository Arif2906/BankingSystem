﻿using BankingSystem.Controllers;
using BankingSystem.Interface;
using BankingSystem.Model;
using NUnit.Framework;

namespace BankingSystemTest
{
    [TestFixture]
    public class UserServiceTests
    {
        private IUserAccountService _userAccountService;
        private IUserService _userService;

        [SetUp]
        public void Setup()
        {
            _userAccountService = new UserAccountService();
            _userService = new UserService(_userAccountService);
        }

        [Test]
        public void CreateUser_ShouldReturnNewUser()
        {
            var userName = "John Doe";
            var user = _userService.CreateUser(userName);
            Assert.NotNull(user);
            Assert.AreEqual(userName, user.Name);
        }
    }
}
