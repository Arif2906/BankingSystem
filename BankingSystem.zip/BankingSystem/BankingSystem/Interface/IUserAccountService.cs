﻿using BankingSystem.Model;

namespace BankingSystem.Interface
{
    public interface IUserAccountService
    {
        List<User> Users { get; }
        List<Account> Accounts { get; }
    }
}
