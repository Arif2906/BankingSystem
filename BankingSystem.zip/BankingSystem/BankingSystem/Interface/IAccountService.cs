﻿using BankingSystem.Model;

namespace BankingSystem.Interface
{
    public interface IAccountService
    {
        Account CreateAccount(int userId);
        decimal Deposit(int accountId, decimal amount);
        decimal Withdraw(int accountId, decimal amount);
        void DeleteAccount(int accountId);

        List<Account> GetAccounts();
    }
}
