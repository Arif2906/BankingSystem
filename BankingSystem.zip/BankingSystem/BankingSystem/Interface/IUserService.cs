﻿using BankingSystem.Model;

namespace BankingSystem.Interface
{
    public interface IUserService
    {
        User CreateUser(string name);
        User GetUser(int userId);
    }
}
