﻿using BankingSystem.Interface;
using BankingSystem.Model;

namespace BankingSystem.Utils
{
    public class HelperFunctions
    {
        private readonly IUserAccountService _userAccountService;

        public HelperFunctions(IUserAccountService userAccountService)
        {
            _userAccountService = userAccountService;
        }
        public int GetMaxUserId()
        {
            return _userAccountService.Users.Count==0 ? 0 : _userAccountService.Users.Max(user => user.Id);
        }

        public int GetMaxAccountId()
        {
            return _userAccountService.Accounts.Count == 0 ? 0 : _userAccountService.Accounts.Max(account => account.Id);
        }
    }
}
