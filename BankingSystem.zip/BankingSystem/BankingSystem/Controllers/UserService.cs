﻿using BankingSystem.Interface;
using BankingSystem.Model;
using BankingSystem.Utils;
using Microsoft.AspNetCore.Mvc;

namespace BankingSystem.Controllers
{
    [ApiController]
    [Route("UserService")]
    public class UserService: IUserService
    {
        private readonly IUserAccountService _userAccountService;

        public UserService(IUserAccountService userAccountService)
        {
            _userAccountService = userAccountService;
        }
        private int _nextUserId = 1;

        [HttpPost("{userId}")]
        public User CreateUser(string name)
        {
            var user = new User { Id = _userAccountService.Users.Count == 0 ? 0 : _userAccountService.Users.Max(user => user.Id)
                , Name = name };
            _userAccountService.Users.Add(user);
            return user;
        }
        [HttpGet]
        public User GetUser(int userId)
        {
            return _userAccountService.Users.FirstOrDefault(a => a.Id == userId);
        }
    }
}
