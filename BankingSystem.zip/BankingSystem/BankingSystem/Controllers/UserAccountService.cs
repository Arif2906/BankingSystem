﻿using BankingSystem.Interface;
using BankingSystem.Model;

namespace BankingSystem.Controllers
{
    public class UserAccountService: IUserAccountService
    {
        public List<User> Users { set; get; } = new List<User>();
        public List<Account> Accounts { set; get; } = new List<Account>();
    }
}
