﻿using BankingSystem.Interface;
using BankingSystem.Model;
using Microsoft.AspNetCore.Mvc;

namespace BankingSystem.Controllers
{
    [ApiController]
    [Route("AccountService")]
    public class AccountService : IAccountService
    {
        private readonly IUserAccountService _userAccountService;
        private readonly IUserService _userService;
        public AccountService(IUserAccountService userAccountService, IUserService userService)
        {
            _userAccountService = userAccountService;
            _userService=userService;
        }
        private int _nextAccountId = 1;

        [HttpPost("CreateAccount/{userId}")]
        public Account CreateAccount(int userId)
        {
            //var user = _userService.GetUser(userId);
            
                var account = new Account { Id = _userAccountService.Accounts.Count == 0 ? 0 : _userAccountService.Accounts.Max(account => account.Id)
                    , UserId = userId, Balance = 0 };
                _userAccountService.Accounts.Add(account);
                return account;
            
            return null;
        }

        [HttpGet]
        public List<Account> GetAccounts()
        {
            return _userAccountService.Accounts;
        }

        [HttpDelete("DeleteAccount/{accountId}")]
        public void DeleteAccount(int accountId)
        {
            var account = _userAccountService.Accounts.FirstOrDefault(a => a.Id == accountId);
            if (account != null)
            {
                _userAccountService.Accounts.Remove(account);
            }
        }

        [HttpPost("Deposit/{accountId}/{amount}")]
        public decimal Deposit(int accountId, decimal amount)
        {
            var account = _userAccountService.Accounts.FirstOrDefault(a => a.Id == accountId);
            if (account != null && amount <= 10000)
            {
                account.Balance += amount;
                return account.Balance;
            }
            return -1;
        }

        [HttpPost("Withdraw/{accountId}/{amount}")]
        public decimal Withdraw(int accountId, decimal amount)
        {
            var account = _userAccountService.Accounts.FirstOrDefault(a => a.Id == accountId);
            if (account != null && account.Balance - amount >= 100 && amount <= account.Balance * 0.9m)
            {
                account.Balance -= amount;
                return account.Balance;
            }
            return -1;
        }
    }
}
